//chrome.runtime.sendMessage({message: "new-tab"}), (response) => {
//    window.close();
//}

chrome.tabs.create({
    url: "chrome://new-tab-page"
});
window.close();