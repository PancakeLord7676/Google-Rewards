if(window.location.href.includes("https://www.bing.com/search")) {
    searched = document.getElementById("sb_form_q").value;
    document.body.innerHTML = "";
    document.head.innerHTML = "";
    window.location.href = "https://www.google.com/search?q="+searched;
}